
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'scottdavidreynolds',
  applicationName: 'signiant-solutions-junmai',
  appUid: '3hV2cLCSdGP3dD61Zy',
  orgUid: 'qkpkGTl5YpMpPr115B',
  deploymentUid: 'e949b043-42e5-4dee-be47-5a87c7af870d',
  serviceName: 'signiant-solutions-junmai',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'signiant-solutions-junmai-dev-junmai-app', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}